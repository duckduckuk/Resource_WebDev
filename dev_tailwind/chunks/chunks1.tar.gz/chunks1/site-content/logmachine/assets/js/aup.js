// CHECK BOX 1 (terms)
$(".aup-answer").hide();
$(".aup-question").click(function() {
    if($(this).is(":checked")) {
        $(".aup-answer").show();
    } else {
        $(".aup-answer").hide();
    }
});
