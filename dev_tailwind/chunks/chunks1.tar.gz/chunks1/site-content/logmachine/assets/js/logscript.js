// ### TEXT BOX ENTRIES

  function EnterNames() {
    var p = document.getElementById('your_paragraph');
    var btn = document.getElementById('btnEnterNames');

// add more here

// Part 1
    var lg =
    document.getElementsByClassName('log');
    var lgname = document.getElementById('box-log').value;
    if (lgname == '') lgname = 'YOU NEED A LOG NUMBER';
    for (i = 0; i < lg.length; i++) {
        lg[i].textContent = lgname;
    }

    var nm =
    document.getElementsByClassName('name');
    var nmname = document.getElementById('box-name').value;
    if (nmname == '') nmname = 'YOU NEED YOUR NAME';
    for (i = 0; i < nm.length; i++) {
        nm[i].textContent = nmname;
    }

    var lt =
    document.getElementsByClassName('company');
    var ltname = document.getElementById('box-company').value;
    if (ltname == '') ltname = 'YOU NEED A COMPANY NAME';
    for (i = 0; i < lt.length; i++) {
        lt[i].textContent = ltname;
    }


// Part 1
  
    var dt =
    document.getElementsByClassName('date');
    var dtname = document.getElementById('box-date').value;
    if (dtname == '') dtname = 'YOU NEED A DATE';
    for (i = 0; i < dt.length; i++) {
        dt[i].textContent = dtname;
    }

    var s =
    document.getElementsByClassName('tmetme');
    var sname = document.getElementById('box-tmetme').value;
    if (sname == '') sname = 'YOU NEED A TIMEFRAME';
    for (i = 0; i < s.length; i++) {
        s[i].textContent = sname;
    }

    var l =
    document.getElementsByClassName('location');
    var lname = document.getElementById('box-location').value;
    if (lname == '') lname = 'YOU NEED A LOCATION';
    for (i = 0; i < l.length; i++) {
        l[i].textContent = lname;
    }

    var s =
    document.getElementsByClassName('breefomeet');
    var sname = document.getElementById('box-breefomeet').value;
    if (sname == '') sname = 'YOU NEED A MEETING TYPE';
    for (i = 0; i < s.length; i++) {
        s[i].textContent = sname;
    }

    var l =
    document.getElementsByClassName('leader');
    var sname = document.getElementById('box-leader').value;
    if (sname == '') sname = 'YOU NEED A MEETING LEADER';
    for (i = 0; i < l.length; i++) {
        l[i].textContent = sname;
    }    

    var t =
    document.getElementsByClassName('topic');
    var tname = document.getElementById('box-topic').value;
    if (tname == '') tname = 'YOU NEED A MEETING TOPIC';
    for (i = 0; i < t.length; i++) {
        t[i].textContent = tname;
    }   

// Part 2
    var k =
    document.getElementsByClassName('machine');
    var kname = document.getElementById('box-machine').value;
    if (kname == '') kname = 'YOU NEED A MACHINE TYPE';
    for (i = 0; i < k.length; i++) {
        k[i].textContent = kname;
    }   
    
    var o =
    document.getElementsByClassName('model');
    var oname = document.getElementById('box-model').value;
    if (oname == '') oname = 'YOU NEED A MACHINE MODEL';
    for (i = 0; i < o.length; i++) {
        o[i].textContent = oname;
    }       

    var c =
    document.getElementsByClassName('check1');
    var cname = document.getElementById('box-check1').value;
    if (cname == '') cname = 'YOU NEED TO MENTION YOU CHECKED(1)';
    for (i = 0; i < c.length; i++) {
        c[i].textContent = cname;
    }       

    var k =
    document.getElementsByClassName('check2');
    var kname = document.getElementById('box-check2').value;
    if (kname == '') kname = 'YOU NEED TO MENTION SOMETHING YOU CHECKED(2)';
    for (i = 0; i < k.length; i++) {
        k[i].textContent = kname;
    }     

// Self Part
    var ts =
    document.getElementsByClassName('task');
    var tsname = document.getElementById('box-task').value;
    if (tsname == '') tsname = '!!!YOU NEED TO ADD DETAILS OF THE TASK YOU CARRIED OUT!!!';
    for (i = 0; i < ts.length; i++) {
        ts[i].textContent = tsname;
    }  
};
// END TEXT BOX ENTRIES
//#####################

// CHECK BOX 1 (terms)
$(".answer").hide();
$(".coupon_question").click(function() {
    if($(this).is(":checked")) {
        $(".answer").show();
    } else {
        $(".answer").hide();
    }
});

// ### NICE BUTTON 2
$(".btn-effect").on("click", function (e) {
    e.preventDefault();
  
    $(this).prepend('<span class="ripple"></span>');
    debugger;
  
    let $ripple = $(".ripple"),
    offSet = $(this).offset(),
    offSetY = e.pageY - offSet.top,
    offSetX = e.pageX - offSet.left;
  
    console.log(offSetY, offSetX);
  
    $ripple.css({
      top: offSetY,
      left: offSetX });
  
  
    // setTimeout(() => {
    //   $ripple.remove();
    // }, 2000);
  });

// COPYCHOMP
  function copyToClipboard(element) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).text()).select();
    document.execCommand("copy");
    $temp.remove();
  }
 
//Setup the part you want to copy with a div ID and then add the following code for a button that copies it:
//<button onclick="copyToClipboard('#p2')">Copy TEXT 2</button>
  
// PRINT TO PDF
$(function () {

    var specialElementHandlers = {
        '#editor': function (element,renderer) {
            return true;
        }
    };
 $('#cmd').click(function () {
        var doc = new jsPDF();
        doc.fromHTML($('#target').html(), 15, 15, {
            'width': 170,'elementHandlers': specialElementHandlers
        });
        doc.save('sample-file.pdf');
    });  
});

//

$(document).ready(function(){
    $('#box-task').focus();
      $('#box-task').autosize();
  });