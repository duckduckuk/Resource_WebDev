module.exports = {
  purge: ['./dist/**/*.html'],
  theme: {
    extend: {},
  },
  variants: {},
  plugins: [],
}
