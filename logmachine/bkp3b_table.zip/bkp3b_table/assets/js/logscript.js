// ### TEXT BOX ENTRIES
// ####################
function EnterNames() {
    var pf = document.getElementById('personal-form');
    var btn = document.getElementById('btnEnterNames');

// add more here
// Part 1
    var t =
    document.getElementsByClassName('box-time');
    var tname = document.getElementById('box-time').value;
    if (tname == '') tname = 'box-time';
    for (i = 0; i < t.length; i++) {
        t[i].textContent = tname;
    }
    var p =
    document.getElementsByClassName('box-place');
    var pname = document.getElementById('box-place').value;
    if (pname == '') tname = 'box-place';
    for (i = 0; i < p.length; i++) {
        p[i].textContent = pname;
    }
    
};
// END TEXT BOX ENTRIES
//#####################

// ### DROP DOWN BOX ENTRIES
// #########################
function GetSelectedValue(){
    var e = document.getElementById("box-meet");
    var result = e.options[e.selectedIndex].value;
    document.getElementById("result").innerHTML = result;
}
function GetSelectedText(){
    var e = document.getElementById("box-meet");
    var result = e.options[e.selectedIndex].text;
    document.getElementById("result").innerHTML = result;
}

// END DROP DOWN BOX ENTRIES
//##########################

//  ### DATE PICKER ENTRIES
// ########################
function dateChanged() {
    const dt = getDatePickerDate('box-date-input');
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('box-date-output').innerHTML = dt.toLocaleDateString([], options);
}

function getDatePickerDate(elementId) {
    const value = document.getElementById(elementId).value
    const [year, month, day] = value.split('-');
    return new Date(year, month - 1, day);
}
// END DATE PICKER BOX ENTRIES
//############################

//  ### SLIDER ENTRIES
// ###################
var slider = document.getElementById("myRange"); 
var output = document.getElementById("demo");
output.value = slider.value; 
function myFunction(x) {
output.value = x.value;
}
// END SLIDER ENTRIES
//###################

//  ### CHECKBOX ENTRIES
// #####################
function check1() {
    // Get the checkbox
    var checkBox = document.getElementById("myCheck");
    // Get the output text
    var text = document.getElementById("text");

    // If the checkbox is checked, display the output text
    if (checkBox.checked == true){
    text.style.display = "block";
    } else {
    text.style.display = "none";
    }
}

  // END CHECKBOX ENTRIES
//#######################

//  RADIOBUT ENTRIES
//##################
function vehicle1func() {
    var userInputgender = document.getElementsByName('vehicle-radio');
    for (var i = 0, length = userInputgender.length; i < length; i++) {
        if (userInputgender[i].checked) {
            document.getElementById('vehicle1').innerHTML = userInputgender[i].value;
            break;
        }
    }
    return false;
}

// END RADIOBUT ENTRIES
//#######################