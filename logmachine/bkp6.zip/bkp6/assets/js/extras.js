
// ### NICE BUTTON 2
$(".btn-effect").on("click", function (e) {
    e.preventDefault();
  
    $(this).prepend('<span class="ripple"></span>');
    debugger;
  
    let $ripple = $(".ripple"),
    offSet = $(this).offset(),
    offSetY = e.pageY - offSet.top,
    offSetX = e.pageX - offSet.left;
  
    console.log(offSetY, offSetX);
  
    $ripple.css({
      top: offSetY,
      left: offSetX });
  
  
    // setTimeout(() => {
    //   $ripple.remove();
    // }, 2000);
  });

// COPYCHOMP
  function copyToClipboard(element) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).text()).select();
    document.execCommand("copy");
    $temp.remove();
  }
 
//Setup the part you want to copy with a div ID and then add the following code for a button that copies it:
//<button onclick="copyToClipboard('#p2')">Copy TEXT 2</button>
  
// PRINT TO PDF
$(function () {

    var specialElementHandlers = {
        '#editor': function (element,renderer) {
            return true;
        }
    };
 $('#cmd').click(function () {
        var doc = new jsPDF();
        doc.fromHTML($('#target').html(), 15, 15, {
            'width': 170,'elementHandlers': specialElementHandlers
        });
        doc.save('sample-file.pdf');
    });  
});