// ### TEXT BOX ENTRIES
function EnterNames() {
    var pf = document.getElementById('personal-form');
    var btn = document.getElementById('btnEnterNames');

// add more here
// Part 1
    var t =
    document.getElementsByClassName('box-time');
    var tname = document.getElementById('box-time').value;
    if (tname == '') tname = 'box-time';
    for (i = 0; i < t.length; i++) {
        t[i].textContent = tname;
    }
    var p =
    document.getElementsByClassName('box-place');
    var pname = document.getElementById('box-place').value;
    if (pname == '') tname = 'box-place';
    for (i = 0; i < p.length; i++) {
        p[i].textContent = pname;
    }
    
};
// END TEXT BOX ENTRIES
//#####################

// ### DROP DOWN BOX ENTRIES

function GetSelectedValue(){
    var e = document.getElementById("box-meet");
    var result = e.options[e.selectedIndex].value;
    document.getElementById("result").innerHTML = result;
}
function GetSelectedText(){
    var e = document.getElementById("box-meet");
    var result = e.options[e.selectedIndex].text;
    document.getElementById("result").innerHTML = result;
}

// END DROP DOWN BOX ENTRIES
//##########################
