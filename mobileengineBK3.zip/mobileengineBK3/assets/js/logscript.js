// ### TEXT BOX ENTRIES
// ####################
function EnterNames() {
    var pf = document.getElementById('form1');
    var pf = document.getElementById('form2');
    var pf = document.getElementById('machine-form');    
    var btn = document.getElementById('btnEnterNames');

// add more here
// Section 1
    var n =
    document.getElementsByClassName('box-name');
    var nname = document.getElementById('box-name').value;
    if (nname == '') nname = 'box-name';
    for (i = 0; i < n.length; i++) {
        n[i].textContent = nname;
    }

    var l =
    document.getElementsByClassName('box-location');
    var lname = document.getElementById('box-location').value;
    if (lname == '') lname = 'box-location';
    for (i = 0; i < l.length; i++) {
        l[i].textContent = lname;
    }

    var d =
    document.getElementsByClassName('box-date');
    var dname = document.getElementById('box-date').value;
    if (dname == '') dname = 'box-date';
    for (i = 0; i < d.length; i++) {
        d[i].textContent = dname;
    }

    var ln =
    document.getElementsByClassName('box-lognumber');
    var lnname = document.getElementById('box-lognumber').value;
    if (lnname == '') lnname = 'box-lognumber';
    for (i = 0; i < ln.length; i++) {
        ln[i].textContent = lnname;
    }

// Section 3
    var vt =
    document.getElementsByClassName('box-type');
    var vtname = document.getElementById('box-type').value;
    if (vtname == '') vtname = 'box-type';
    for (i = 0; i < vt.length; i++) {
        vt[i].textContent = vtname;
    }
    var vm =
    document.getElementsByClassName('box-model');
    var vmname = document.getElementById('box-model').value;
    if (vmname == '') vmname = 'box-model';
    for (i = 0; i < vm.length; i++) {
        vm[i].textContent = vmname;
    }
    var ic =
    document.getElementsByClassName('box-inspection');
    var icname = document.getElementById('box-inspection').value;
    if (icname == '') icname = 'I checked but everything was in good order. Even though nothing was wrong in the inspection, I still entered "no faults" into the log as it is required by our company policy';
    for (i = 0; i < ic.length; i++) {
        ic[i].textContent = icname;
    }    
    var wa =
    document.getElementsByClassName('box-workactivity');
    var waname = document.getElementById('box-workactivity').value;
    if (waname == '') waname = '!!!IMPORTANT!!! WORK DETAILS MISSING !!!IMPORTANT!!! WORK DETAILS MISSING !!!IMPORTANT!!! WORK DETAILS MISSING !!!IMPORTANT!!! WORK DETAILS MISSING !!!IMPORTANT!!! WORK DETAILS MISSING ';
    for (i = 0; i < wa.length; i++) {
        wa[i].textContent = waname;
    }        

// END TEXT BOX ENTRIES
//#####################

// ### DROP DOWN BOX ENTRIES
// #########################
function GetSelectedValueMeet(){
    var e = document.getElementById("box-type");
    var result = e.options[e.selectedIndex].value;
    document.getElementById("result-btp").innerHTML = result;
}
function GetSelectedTextMeet(){
    var e = document.getElementById("box-type");
    var result = e.options[e.selectedIndex].text;
    document.getElementById("result-btp").innerHTML = result;
}

//

function GetSelectedValueTalk(){
    var e = document.getElementById("box-talker");
    var result = e.options[e.selectedIndex].value;
    document.getElementById("result-bt").innerHTML = result;
}
function GetSelectedTextTalk(){
    var e = document.getElementById("box-talker");
    var result = e.options[e.selectedIndex].text;
    document.getElementById("result-bt").innerHTML = result;
}
// END DROP DOWN BOX ENTRIES
//##########################

//  ### DATE PICKER ENTRIES - see text entrys (d) for output.
// ########################
function dateChanged() {
    const dt = getDatePickerDate('box-date');
    const options = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
    document.getElementById('box-date').innerHTML = dt.toLocaleDateString([], options);
}

function getDatePickerDate(elementId) {
    const value = document.getElementById(elementId).value
    const [day, month, year] = value.split('-');
    return new Date(day, month - 1, year), weekday;
}

//# V2



// END DATE PICKER BOX ENTRIES
//############################

//  ### SLIDER ENTRIES
// ###################
var slider = document.getElementById("myRange"); 
var output = document.getElementById("demo");
output.value = slider.value; 
function myFunction(x) {
output.value = x.value;
}
// END SLIDER ENTRIES
//###################

//  ### CHECKBOX ENTRIES
// #####################
function check1() {
    // Get the checkbox
    var checkBox = document.getElementById("myCheck");
    // Get the output text
    var text = document.getElementById("text");

    // If the checkbox is checked, display the output text
    if (checkBox.checked == true){
    text.style.display = "block";
    } else {
    text.style.display = "none";
    }
}

  // END CHECKBOX ENTRIES
//#######################

//  RADIOBUT ENTRIES
//##################
function vehicle1func() {
    var userInputgender = document.getElementsByName('vehicle-radio');
    for (var i = 0, length = userInputgender.length; i < length; i++) {
        if (userInputgender[i].checked) {
            document.getElementById('vehicle1').innerHTML = userInputgender[i].value;
            break;
        }
    }
    return false;
}

// END RADIOBUT ENTRIES
}

