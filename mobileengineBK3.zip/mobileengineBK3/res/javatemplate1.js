    var ## =
    document.getElementsByClassName('box-date');
    var ##name = document.getElementById('box-date').value;
    if (##name == '') ##name = 'box-date';
    for (i = 0; i < ##.length; i++) {
        ##[i].textContent = ##name;
    }